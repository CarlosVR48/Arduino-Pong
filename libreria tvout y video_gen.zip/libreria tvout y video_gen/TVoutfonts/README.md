Copy this folder to your Arduino libraries folder
